import { useState, useEffect, useCallback } from 'react';

const api = async (path, method = 'GET', body) => {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (localStorage.getItem('t') || '') }, body: body && JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Something went wrong');
  return d;
};
const useList = (path, on = true) => {
  const [data, setData] = useState([]);
  const load = useCallback(() => { if (on) api(path).then(setData).catch(() => {}); }, [path, on]);
  useEffect(load, [load]);
  return [data, load];
};
const fmt = (d) => new Date(d).toLocaleDateString();

function Form({ fields, onSubmit, label }) {
  const [v, setV] = useState({}); const [err, setErr] = useState('');
  const set = (k, x) => setV((p) => ({ ...p, [k]: x }));
  return (
    <form onSubmit={async (e) => { e.preventDefault(); try { await onSubmit(v); setV({}); setErr(''); } catch (x) { setErr(x.message); } }}>
      {fields.map((f) => (
        <label key={f.name}>{f.label}
          {f.options ? (
            <select multiple={f.multi} required={!f.optional} value={v[f.name] || (f.multi ? [] : '')}
              onChange={(e) => set(f.name, f.multi ? [...e.target.selectedOptions].map((o) => o.value) : e.target.value)}>
              {!f.multi && <option value="">{f.optional ? 'None' : 'Select'}</option>}
              {f.options.map((o) => <option key={o.v ?? o} value={o.v ?? o}>{o.l ?? o}</option>)}
            </select>
          ) : f.area ? <textarea rows="3" required={!f.optional} value={v[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
            : <input type={f.type || 'text'} required={!f.optional} value={v[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />}
        </label>
      ))}
      {err && <p className="err" role="alert">{err}</p>}
      <button>{label}</button>
    </form>
  );
}

function Announcements({ user }) {
  const [items, load] = useList('/announcements');
  return (<>
    <h2>Announcements</h2>
    {user.role === 'hr' && <div className="card"><Form label="Post announcement" onSubmit={async (v) => { await api('/announcements', 'POST', v); load(); }}
      fields={[{ name: 'title', label: 'Title' }, { name: 'body', label: 'Message', area: true }]} /></div>}
    {!items.length && <p className="muted">No announcements yet.</p>}
    {items.map((a) => <div className="card" key={a._id}><h3 style={{ margin: 0 }}>{a.title}</h3>
      <p className="muted" style={{ margin: '2px 0 8px' }}>{a.author?.name} on {fmt(a.createdAt)}</p><p style={{ margin: 0 }}>{a.body}</p>
      {user.role === 'hr' && <button className="btn ghost" style={{ marginTop: 10 }} onClick={async () => { await api('/announcements/' + a._id, 'DELETE'); load(); }}>Delete</button>}</div>)}
  </>);
}

function Leaves({ user }) {
  const [items, load] = useList('/leaves'); const reviewer = user.role !== 'employee';
  const review = async (id, status) => { try { await api('/leaves/' + id, 'PATCH', { status }); load(); } catch (e) { alert(e.message); } };
  return (<>
    <h2>Leave</h2>
    <div className="card"><Form label="Apply for leave" onSubmit={async (v) => { await api('/leaves', 'POST', v); load(); }}
      fields={[{ name: 'type', label: 'Leave type', options: ['Casual', 'Sick', 'Earned', 'Unpaid'] }, { name: 'from', label: 'From', type: 'date' },
        { name: 'to', label: 'To', type: 'date' }, { name: 'reason', label: 'Reason', optional: true }]} /></div>
    <div className="card scroll"><table><thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Status</th>{reviewer && <th></th>}</tr></thead><tbody>
      {items.map((l) => <tr key={l._id}><td>{l.user?.name}</td><td>{l.type}</td><td>{fmt(l.from)} to {fmt(l.to)}</td><td><span className={'tag ' + l.status}>{l.status}</span></td>
        {reviewer && <td>{l.status === 'pending' && l.user?._id !== user._id && <span className="row"><button className="btn ghost" onClick={() => review(l._id, 'approved')}>Approve</button><button className="btn ghost" onClick={() => review(l._id, 'rejected')}>Reject</button></span>}</td>}</tr>)}
    </tbody></table>{!items.length && <p className="muted">No leave requests yet.</p>}</div>
  </>);
}

function Attendance({ user }) {
  const [items, load] = useList('/attendance'); const [msg, setMsg] = useState('');
  const mark = async () => { try { await api('/attendance', 'POST'); setMsg('Attendance marked for today.'); load(); } catch (e) { setMsg(e.message === 'Already exists' ? 'You already marked attendance today.' : e.message); } };
  return (<>
    <h2>Attendance</h2>
    <div className="card row" style={{ alignItems: 'center' }}><button className="btn" onClick={mark}>Mark today's attendance</button><span role="status">{msg}</span></div>
    <div className="card scroll"><table><thead><tr>{user.role === 'hr' && <th>Employee</th>}<th>Date</th><th>Checked in</th></tr></thead><tbody>
      {items.map((a) => <tr key={a._id}>{user.role === 'hr' && <td>{a.user?.name}</td>}<td>{a.date}</td><td>{new Date(a.checkIn).toLocaleTimeString()}</td></tr>)}
    </tbody></table>{!items.length && <p className="muted">No attendance records yet.</p>}</div>
  </>);
}

function Profile({ user, setUser }) {
  const [saved, setSaved] = useState(false); const [v, setV] = useState(user);
  const f = (k, label) => <label>{label}<input value={v[k] || ''} onChange={(e) => { setV({ ...v, [k]: e.target.value }); setSaved(false); }} /></label>;
  return (<><h2>My record</h2><div className="card"><form onSubmit={async (e) => { e.preventDefault(); setUser(await api('/me', 'PUT', v)); setSaved(true); }}>
    {f('name', 'Name')}{f('department', 'Department')}{f('phone', 'Phone')}{f('address', 'Address')}
    <p className="muted" style={{ margin: 0 }}>{user.email} | role: {user.role}</p><button>Save changes</button>{saved && <span role="status">Saved</span>}</form></div></>);
}

function Employees() {
  const [items, load] = useList('/employees'); const managers = items.filter((e) => e.role === 'manager').map((m) => ({ v: m._id, l: m.name }));
  const upd = async (id, body) => { await api('/employees/' + id, 'PUT', body); load(); };
  return (<>
    <h2>Employees</h2>
    <div className="card"><Form label="Add employee" onSubmit={async (v) => { await api('/employees', 'POST', v); load(); }}
      fields={[{ name: 'name', label: 'Name' }, { name: 'email', label: 'Email', type: 'email' }, { name: 'department', label: 'Department', optional: true },
        { name: 'role', label: 'Role', options: ['employee', 'manager', 'hr'] }, { name: 'manager', label: 'Reports to', options: managers, optional: true },
        { name: 'password', label: 'Starting password (default Welcome123)', optional: true }]} /></div>
    <div className="card scroll"><table><thead><tr><th>Name</th><th>Email</th><th>Department</th><th>Role</th><th>Reports to</th><th></th></tr></thead><tbody>
      {items.map((e) => <tr key={e._id}><td>{e.name}</td><td>{e.email}</td><td>{e.department}</td>
        <td><select aria-label="Role" value={e.role} onChange={(x) => upd(e._id, { role: x.target.value })}>{['employee', 'manager', 'hr'].map((r) => <option key={r}>{r}</option>)}</select></td>
        <td><select aria-label="Manager" value={e.manager?._id || ''} onChange={(x) => upd(e._id, { manager: x.target.value })}><option value="">None</option>{managers.filter((m) => m.v !== e._id).map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}</select></td>
        <td><button className="btn ghost" onClick={async () => { if (confirm('Delete ' + e.name + '?')) { await api('/employees/' + e._id, 'DELETE'); load(); } }}>Delete</button></td></tr>)}
    </tbody></table></div>
  </>);
}

function Training({ user }) {
  const [items, load] = useList('/training'); const [team] = useList('/employees', user.role === 'manager');
  return (<>
    <h2>Training and development</h2>
    {user.role === 'manager' && <div className="card"><Form label="Create program" onSubmit={async (v) => { await api('/training', 'POST', v); load(); }}
      fields={[{ name: 'title', label: 'Program title' }, { name: 'description', label: 'Description', optional: true }, { name: 'date', label: 'Start date', type: 'date' },
        { name: 'team', label: 'Team members (hold Ctrl or Cmd for several)', multi: true, optional: true, options: team.map((t) => ({ v: t._id, l: t.name })) }]} /></div>}
    {!items.length && <p className="muted">No training programs yet.</p>}
    {items.map((t) => <div className="card" key={t._id}><h3 style={{ margin: 0 }}>{t.title}</h3><p className="muted" style={{ margin: '2px 0 8px' }}>{t.date && fmt(t.date)}</p>
      <p style={{ margin: 0 }}>{t.description}</p><p className="muted">Team: {t.team.map((m) => m.name).join(', ') || 'No one assigned'}</p>
      {user.role === 'manager' && <button className="btn ghost" onClick={async () => { await api('/training/' + t._id, 'DELETE'); load(); }}>Delete</button>}</div>)}
  </>);
}

function Login({ onAuth }) {
  const [reg, setReg] = useState(false);
  return (<div className="login"><h1>Staff<span style={{ color: 'var(--accent)' }}>Sync</span></h1>
    <p className="muted">{reg ? 'Create your account. The first account becomes HR.' : 'Sign in to your workspace.'}</p>
    <div className="card"><Form label={reg ? 'Create account' : 'Sign in'} onSubmit={async (v) => { const d = await api(reg ? '/auth/register' : '/auth/login', 'POST', v); localStorage.setItem('t', d.token); onAuth(d.user); }}
      fields={[...(reg ? [{ name: 'name', label: 'Full name' }] : []), { name: 'email', label: 'Email', type: 'email' }, { name: 'password', label: 'Password', type: 'password' }]} /></div>
    <button className="btn ghost" onClick={() => setReg(!reg)}>{reg ? 'I already have an account' : 'Create an account'}</button></div>);
}

export default function App() {
  const [user, setUser] = useState(null); const [ready, setReady] = useState(false); const [tab, setTab] = useState('Announcements');
  useEffect(() => { api('/me').then(setUser).catch(() => {}).finally(() => setReady(true)); }, []);
  if (!ready) return null;
  if (!user) return <Login onAuth={setUser} />;
  const pages = { Announcements: <Announcements user={user} />, Leave: <Leaves user={user} />, Attendance: <Attendance user={user} />, 'My record': <Profile user={user} setUser={setUser} /> };
  if (user.role === 'hr') pages.Employees = <Employees />;
  pages.Training = <Training user={user} />;
  return (<div className="shell"><aside><h1>Staff<span>Sync</span></h1>
    {Object.keys(pages).map((p) => <button key={p} className={tab === p ? 'on' : ''} onClick={() => setTab(p)}>{p}</button>)}
    <button onClick={() => { localStorage.removeItem('t'); setUser(null); }}>Sign out</button>
    <div className="who">{user.name}<br />{user.role}</div></aside><main>{pages[tab] || pages.Announcements}</main></div>);
}
