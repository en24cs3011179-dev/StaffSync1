# StaffSync

HR management app on the MERN stack. Roles: HR, manager, employee.

## Run it
1. Start MongoDB locally (default port 27017).
2. API: `cd server && cp .env.example .env` (set JWT_SECRET), then `npm install && npm run dev` (port 5000).
3. Web: `cd client && npm install && npm run dev`, then open http://localhost:5173.

The first account you register becomes HR. HR can then add employees, set roles and assign managers.

## What each role can do
- HR: employees (add, change role, assign manager, delete), approve or reject any leave, view all attendance, post and delete announcements.
- Manager: approve or reject leave for direct reports, create training programs for their team.
- Employee: apply for leave, mark attendance, edit their own record, read announcements, see training they are assigned to.

## Test the API in Postman
POST /api/auth/login returns a token. Send it as `Authorization: Bearer <token>` on other routes.
