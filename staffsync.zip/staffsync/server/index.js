require('dotenv').config();
const express = require('express'), cors = require('cors'), mongoose = require('mongoose');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken');
const { User, Leave, Attendance, Announcement, Training } = require('./models');
const app = express(); app.use(cors()); app.use(express.json());
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(e.code === 11000 ? 409 : 400).json({ error: e.code === 11000 ? 'Already exists' : e.message }));
const sign = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const clean = (u) => { const o = u.toObject(); delete o.password; return o; };

const auth = async (req, res, next) => {
  try {
    const { id } = jwt.verify((req.headers.authorization || '').slice(7), process.env.JWT_SECRET);
    req.user = await User.findById(id); if (!req.user) throw 0; next();
  } catch { res.status(401).json({ error: 'Please sign in' }); }
};
const only = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'Not allowed for your role' });

// Auth: the very first account becomes HR; later sign-ups are employees
app.post('/api/auth/register', wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || (password || '').length < 6) throw new Error('Name, email and a 6+ character password are required');
  const role = (await User.countDocuments()) === 0 ? 'hr' : 'employee';
  const u = await User.create({ name, email, password: await bcrypt.hash(password, 10), role });
  res.json({ token: sign(u), user: clean(u) });
}));
app.post('/api/auth/login', wrap(async (req, res) => {
  const u = await User.findOne({ email: (req.body.email || '').toLowerCase() });
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password))) return res.status(401).json({ error: 'Wrong email or password' });
  res.json({ token: sign(u), user: clean(u) });
}));
app.get('/api/me', auth, (req, res) => res.json(clean(req.user)));
app.put('/api/me', auth, wrap(async (req, res) => {
  const { name, phone, address, department } = req.body;
  Object.assign(req.user, { name: name || req.user.name, phone, address, department }); await req.user.save(); res.json(clean(req.user));
}));

// Employees (HR manages; managers see their team)
app.get('/api/employees', auth, only('hr', 'manager'), wrap(async (req, res) => {
  const q = req.user.role === 'hr' ? {} : { manager: req.user._id };
  res.json(await User.find(q).select('-password').populate('manager', 'name').sort('name'));
}));
app.post('/api/employees', auth, only('hr'), wrap(async (req, res) => {
  const { password = 'Welcome123', manager, ...rest } = req.body;
  const u = await User.create({ ...rest, manager: manager || undefined, password: await bcrypt.hash(password, 10) }); res.json(clean(u));
}));
app.put('/api/employees/:id', auth, only('hr'), wrap(async (req, res) => {
  const { password, ...rest } = req.body; if (rest.manager === '') rest.manager = null;
  res.json(await User.findByIdAndUpdate(req.params.id, rest, { new: true }).select('-password'));
}));
app.delete('/api/employees/:id', auth, only('hr'), wrap(async (req, res) => { await User.findByIdAndDelete(req.params.id); res.json({ ok: true }); }));

// Leaves
app.post('/api/leaves', auth, wrap(async (req, res) => {
  const { type, from, to, reason } = req.body;
  if (new Date(to) < new Date(from)) throw new Error('End date must be on or after the start date');
  res.json(await Leave.create({ type, from, to, reason, user: req.user._id }));
}));
app.get('/api/leaves', auth, wrap(async (req, res) => {
  let q = { user: req.user._id };
  if (req.user.role === 'hr') q = {};
  if (req.user.role === 'manager') q = { user: { $in: (await User.find({ manager: req.user._id }).distinct('_id')).concat(req.user._id) } };
  res.json(await Leave.find(q).populate('user', 'name department').sort('-createdAt'));
}));
app.patch('/api/leaves/:id', auth, only('hr', 'manager'), wrap(async (req, res) => {
  const l = await Leave.findById(req.params.id).populate('user');
  if (req.user.role === 'manager' && String(l.user.manager) !== String(req.user._id)) return res.status(403).json({ error: 'Not your team member' });
  if (String(l.user._id) === String(req.user._id)) return res.status(403).json({ error: 'You cannot review your own leave' });
  if (!['approved', 'rejected'].includes(req.body.status)) throw new Error('Invalid status');
  l.status = req.body.status; await l.save(); res.json(l);
}));

// Attendance
app.post('/api/attendance', auth, wrap(async (req, res) => {
  const date = new Date().toISOString().slice(0, 10);
  res.json(await Attendance.create({ user: req.user._id, date, checkIn: new Date() }));
}));
app.get('/api/attendance', auth, wrap(async (req, res) => {
  const q = req.user.role === 'hr' ? {} : { user: req.user._id };
  res.json(await Attendance.find(q).populate('user', 'name').sort('-checkIn').limit(200));
}));

// Announcements
app.get('/api/announcements', auth, wrap(async (_req, res) => res.json(await Announcement.find().populate('author', 'name').sort('-createdAt'))));
app.post('/api/announcements', auth, only('hr'), wrap(async (req, res) => res.json(await Announcement.create({ ...req.body, author: req.user._id }))));
app.delete('/api/announcements/:id', auth, only('hr'), wrap(async (req, res) => { await Announcement.findByIdAndDelete(req.params.id); res.json({ ok: true }); }));

// Training & development
app.get('/api/training', auth, wrap(async (req, res) => {
  const q = req.user.role === 'hr' ? {} : req.user.role === 'manager' ? { manager: req.user._id } : { team: req.user._id };
  res.json(await Training.find(q).populate('team', 'name').sort('date'));
}));
app.post('/api/training', auth, only('manager'), wrap(async (req, res) => res.json(await Training.create({ ...req.body, manager: req.user._id }))));
app.delete('/api/training/:id', auth, only('manager'), wrap(async (req, res) => { await Training.deleteOne({ _id: req.params.id, manager: req.user._id }); res.json({ ok: true }); }));

mongoose.connect(process.env.MONGO_URI).then(() => app.listen(process.env.PORT || 5000, () => console.log('StaffSync API running'))).catch((e) => { console.error(e.message); process.exit(1); });
