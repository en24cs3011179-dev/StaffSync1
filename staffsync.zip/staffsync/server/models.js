const { Schema, model } = require('mongoose');
const ref = (m) => ({ type: Schema.Types.ObjectId, ref: m });
const User = model('User', new Schema({
  name: { type: String, required: true }, email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true }, role: { type: String, enum: ['employee', 'manager', 'hr'], default: 'employee' },
  department: String, phone: String, address: String, manager: ref('User'),
}, { timestamps: true }));
const Leave = model('Leave', new Schema({
  user: ref('User'), type: { type: String, enum: ['Casual', 'Sick', 'Earned', 'Unpaid'], required: true },
  from: { type: Date, required: true }, to: { type: Date, required: true }, reason: String,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
}, { timestamps: true }));
const attSchema = new Schema({ user: ref('User'), date: String, checkIn: Date });
attSchema.index({ user: 1, date: 1 }, { unique: true });
const Attendance = model('Attendance', attSchema);
const Announcement = model('Announcement', new Schema({ title: String, body: String, author: ref('User') }, { timestamps: true }));
const Training = model('Training', new Schema({
  title: { type: String, required: true }, description: String, date: Date, manager: ref('User'), team: [ref('User')],
}, { timestamps: true }));
module.exports = { User, Leave, Attendance, Announcement, Training };
